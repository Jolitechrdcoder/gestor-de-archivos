﻿----------------------------------------------------------------------
 Radmin 3.5.2.1 Remote Control para Windows 10/8/7/Vista/XP/2012/2008/2003/2000/NT/ME/9x (32-bit y 64-bit)

 Todos los componentes del módulo RServer3 © 1999-2017 Dmitry Znosko. Todos los derechos reservados.
 Radmin Viewer components © 1999-2017 Dmitry Znosko. Todos los derechos reservados.
 (C) 1999-2017 Famatech Corp. y sus distribuidores. Todos los derechos reservados.
 Fecha: 14.12.2017

----------------------------------------------------------------------

Toda la ayuda está disponible en el archivo 'radmin30.chm'.
Sitio web: http://www.radmin.es

----------------------------------------------------------------------
 RADMIN 3.5.2.1
----------------------------------------------------------------------

Índice:

* Acerca de Radmin
* Requisitos del sistema
* Instalación
  - Instalación de Radmin Server 3.5.2.1
  - Instalación de Radmin Viewer 3.5.2.1
* Establecimiento de la conexión
* Nuestros datos de contacto

----------------------------------------------------------------------
 Acerca de Radmin
----------------------------------------------------------------------

Radmin es un software de acceso y control remoto seguro que permite trabajar sobre un equipo remoto como si estuviera sentado delante, y tener acceso desde varios sitios.

Radmin 3.5.2.1 consta de dos módulos:

* Radmin Viewer 3.5.2.1 debe haberse instalado en el equipo local (un ejemplo, su ordenador de casa o portátil) que desea utilizar para tener acceso al equipo remoto.

* Radmin Server 3.5.2.1 debe haberse instalado en el equipo remoto (por ejemplo, el ordenador de su oficina) al que desea tener acceso desde el suyo propio (ejemplo, su ordenador de casa o portátil).

Para empezar a trabajar, asegúrese de que Radmin Server se esté ejecutando en el equipo remoto. A continuación, ejecute Radmin Viewer en el equipo local y conecte al equipo remoto. 

----------------------------------------------------------------------
 Requisitos del sistema
----------------------------------------------------------------------

* Radmin Viewer se puede ejecutar en Windows 10/8/7/Vista/XP/2012/2008/2003/2000/NT/ME/9x de 32-bit y Windows 10/8/7/Vista/XP/2012/2008/2003 de 64-bit. 
* Radmin Server se puede ejecutar en Windows 10/8/7/Vista/XP/2012/2008/2003/2000 de 32-bit y Windows 10/8/7/Vista/XP/2012/2008/2003 de 64-bit.

Si necesita Radmin Server para Windows NT/ME/9x puede utilizar Radmin Server 2.2
http://www.radmin.com/products/previousversions/radmin22.php
Radmin Viewer 3.5.2.1 es totalmente compatible con Radmin Server 2.2

Los dos equipos deben estar conectados mediante TCP/IP en una red local, directamente por módem, o a través de Internet. 

----------------------------------------------------------------------
 Instalación
----------------------------------------------------------------------

 Instalación de Radmin Server 3.5.2.1:
-----------------------------

1. Ejecute Radmin_Server_3.5.2.1_ES.msi para instalar Radmin Server.

2. Siga las instrucciones en pantalla. El instalador copia todos los archivos necesarios en el directorio de sistema predeterminado.

Nota: Cuando haya caducado el período de pruebas de 30 días, Radmin Server requiere una licencia para seguir funcionando. Cuando adquiera una licencia de programa, Famatech le entregará un código de licencia que permite desbloquear Radmin Server para su uso continuado. Para más información, visite la tienda virtual. http://www.radmin.es/ordering/

 Instalación de Radmin Viewer 3.5.2.1:
-----------------------------

1. Ejecute Radmin_Viewer_3.5.2.1_ES.msi para instalar Radmin Viewer.

2. Siga las instrucciones en pantalla y seleccione un directorio de instalación cuando se le pida. El instalador copia todos los archivos necesarios en el directorio especificado.

----------------------------------------------------------------------
 Establecimiento de conexión
----------------------------------------------------------------------

1. Para configurar Radmin Server en el equipo remoto:

Haga clic con el botón secundario en el icono de la bandeja de sistema Radmin Server 3.3 y elija "Configuración para Radmin Server". Seleccione el botón "Permisos" para establecer la contraseña de acceso de red para el equipo Radmin Server.

Si utiliza el firewall de Windows 10/8/7/Vista/XP, el archivo rserver3.exe se añadirá a la lista de excepciones del mismo durante la instalación.

Debe conocer la dirección IP del equipo remoto. Para saberla, mueva el puntero del ratón sobre el icono Radmin Server de la bandeja del sistema. Una ventana informativa le indicará la dirección IP.

2. Ejecución de Radmin Viewer en el equipo local:

Desde el menú Inicio, haga clic en "Radmin Viewer", cree una nueva conexión y escriba la dirección IP del equipo remoto. Entonces, seleccione el tipo de conexión y pulse "Conectar". Escriba la misma contraseña configurada en el equipo remoto.

----------------------------------------------------------------------
 Nuestros datos de contacto
----------------------------------------------------------------------

Utilice el inglés cuando se ponga en contacto con el personal de Famatech.

Ventas
http://www.radmin.es/ordering/

Soporte técnico
http://www.radmin.com/support/

Visite nuestro sitio para conocer las últimas noticias, versiones y actualizaciones:
http://www.radmin.es

----------------------------------------------------------------------

 Todos los componentes del módulo RServer3 © 1999-2017 Dmitry Znosko. Todos los derechos reservados.
 Radmin Viewer components © 1999-2017 Dmitry Znosko. Todos los derechos reservados.
 (C) 1999-2017 Famatech Corp. y sus distribuidores. Todos los derechos reservados.
